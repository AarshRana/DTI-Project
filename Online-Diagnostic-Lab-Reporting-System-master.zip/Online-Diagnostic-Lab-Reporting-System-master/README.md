# Online-Diagnostic-Lab-Reporting-System

The system is an online diagnostic lab manager application that brings up various diagnoses working online. Here patients are first allowed to register on the site and also login using registered details. Patients may now see a variety of tests conducted by the lab along with their costs. Now the system allows users to book any test needed. After successful booking system calculates costs and allows users to pay online. After successful testing the user now gets a notification of test result through an email.

Why Use?

-Allows for faster service

-It reduces employment as the human efforts

-Easy , user friendly GUI

-Allows increased sales and profits for diagnostic labs

Objectives of the Project:

=> Establish an Online Diagnostic Lab Reporting System 

=>Patients can take the appointment online 

=>It is going to be very much helpful

=>The system will help the diagnostic centre to track all their patients details

 =>This provides quick and effective services
 
 Technologies used:
 
 Language: PHP
 
 Server: XAMPP
 
 HTML, CSS, BOOTSTRAP, JQuey 
 
 Installation:
 
 Clone or Download
 
 Go to localhost/phpmyadmin
 
 Import the file named registration.sql



Here is the full overview:

![picture1](https://user-images.githubusercontent.com/33178053/38770066-db8a8714-402e-11e8-9bd9-64278ac42f91.png)

![picture2](https://user-images.githubusercontent.com/33178053/38770067-dbd9b50a-402e-11e8-9ca9-8031d36d7995.png)

![picture3](https://user-images.githubusercontent.com/33178053/38770068-dc1b807a-402e-11e8-8ce3-81a348605888.PNG)

![picture4](https://user-images.githubusercontent.com/33178053/38770069-dc56a3ee-402e-11e8-9d6b-08005a0d9c73.png)

![picture5](https://user-images.githubusercontent.com/33178053/38770070-dc935406-402e-11e8-9b69-3b4c5f57152a.png)
